Skeleton project for Prometheus actuator scraping.
Add the remaining classes from the design:
- MonitorProperties
- MetricSnapshot
- PrometheusParser
- MetricsScraper
- ReportWriter
