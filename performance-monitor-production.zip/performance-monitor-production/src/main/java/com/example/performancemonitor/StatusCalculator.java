package com.example.performancemonitor;

import org.springframework.stereotype.Component;

@Component
public class StatusCalculator {
    private final MonitorProperties properties;

    public StatusCalculator(MonitorProperties properties) {
        this.properties = properties;
    }

    public String calculate(ReportRow row) {
        if (!"OK".equals(row.scrapeStatus())) return "SCRAPE_FAILED";

        var t = properties.thresholds();

        if (row.avgResponseMs() >= t.verySlowResponseMs()) return "CRITICAL_SLOW_RESPONSE";
        if (row.jdbcUsagePct() >= t.jdbcUsageCriticalPct() || row.jdbcPending() > 0) return "DB_POOL_SATURATED";
        if (row.heapUsedPct() >= t.heapCriticalPct()) return "CRITICAL_HEAP";
        if (row.processCpuPct() >= t.cpuCriticalPct()) return "CRITICAL_CPU";

        if (row.avgResponseMs() >= t.slowResponseMs()) return "SLOW_RESPONSE";
        if (row.jdbcUsagePct() >= t.jdbcUsageWarningPct()) return "HIGH_DB_POOL_USAGE";
        if (row.heapUsedPct() >= t.heapWarningPct()) return "HIGH_HEAP";
        if (row.processCpuPct() >= t.cpuWarningPct()) return "HIGH_CPU";
        if (row.blockedThreads() >= t.blockedThreadsWarning()) return "THREAD_BLOCKING";
        if (row.activeRequests() >= t.activeRequestsWarning()) return "REQUESTS_IN_PROGRESS_HIGH";

        if (row.requestsPerMinute() == 0 && row.activeRequests() == 0 && row.processCpuPct() < 10) {
            return "IDLE_WAITING_FOR_REQUESTS";
        }

        return "HEALTHY";
    }
}
