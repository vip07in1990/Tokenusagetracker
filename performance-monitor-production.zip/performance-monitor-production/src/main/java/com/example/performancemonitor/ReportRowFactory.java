package com.example.performancemonitor;

import org.springframework.stereotype.Component;
import java.time.Duration;

@Component
public class ReportRowFactory {
    private final StatusCalculator statusCalculator;

    public ReportRowFactory(StatusCalculator statusCalculator) {
        this.statusCalculator = statusCalculator;
    }

    public ReportRow create(MetricSnapshot current, MetricSnapshot previous) {
        double seconds = 60;
        double requestDelta = 0;
        double sumDelta = 0;
        double gcCountDelta = 0;
        double gcSumDelta = 0;

        if (previous != null) {
            seconds = Math.max(1, Duration.between(previous.timestamp, current.timestamp).toMillis() / 1000.0);
            requestDelta = Math.max(0, current.requestCount - previous.requestCount);
            sumDelta = Math.max(0, current.requestSumSeconds - previous.requestSumSeconds);
            gcCountDelta = Math.max(0, current.gcPauseCount - previous.gcPauseCount);
            gcSumDelta = Math.max(0, current.gcPauseSumSeconds - previous.gcPauseSumSeconds);
        }

        double rpm = requestDelta * 60.0 / seconds;
        double avgResponseMs = requestDelta > 0 ? (sumDelta / requestDelta) * 1000.0 : 0;
        double jdbcUsagePct = current.jdbcMax > 0 ? current.jdbcActive * 100.0 / current.jdbcMax : 0;
        double heapUsedPct = current.heapMaxBytes > 0 ? current.heapUsedBytes * 100.0 / current.heapMaxBytes : 0;
        double avgGcPauseMs = gcCountDelta > 0 ? (gcSumDelta / gcCountDelta) * 1000.0 : 0;

        ReportRow noStatus = new ReportRow(
                current.timestamp, current.service, current.scrapeStatus, current.scrapeError,
                requestDelta, rpm, avgResponseMs, current.activeRequests,
                current.jdbcActive, current.jdbcMax, current.jdbcPending, jdbcUsagePct,
                current.processCpu * 100, current.systemCpu * 100, current.liveThreads,
                current.runnableThreads, current.blockedThreads, current.waitingThreads,
                current.timedWaitingThreads, heapUsedPct, gcCountDelta, avgGcPauseMs, "PENDING"
        );

        return new ReportRow(
                noStatus.timestamp(), noStatus.service(), noStatus.scrapeStatus(), noStatus.scrapeError(),
                noStatus.requestDelta(), noStatus.requestsPerMinute(), noStatus.avgResponseMs(),
                noStatus.activeRequests(), noStatus.jdbcActive(), noStatus.jdbcMax(), noStatus.jdbcPending(),
                noStatus.jdbcUsagePct(), noStatus.processCpuPct(), noStatus.systemCpuPct(), noStatus.liveThreads(),
                noStatus.runnableThreads(), noStatus.blockedThreads(), noStatus.waitingThreads(),
                noStatus.timedWaitingThreads(), noStatus.heapUsedPct(), noStatus.gcPauseDelta(),
                noStatus.avgGcPauseMs(), statusCalculator.calculate(noStatus)
        );
    }
}
