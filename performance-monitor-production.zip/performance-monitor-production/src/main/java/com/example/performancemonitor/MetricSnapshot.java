package com.example.performancemonitor;

import java.time.Instant;

public class MetricSnapshot {
    public Instant timestamp;
    public String service;
    public String scrapeStatus = "OK";
    public String scrapeError = "";

    public double requestCount;
    public double requestSumSeconds;
    public double activeRequests;

    public double jdbcActive;
    public double jdbcIdle;
    public double jdbcMax;
    public double jdbcPending;

    public double processCpu;
    public double systemCpu;

    public double liveThreads;
    public double daemonThreads;
    public double blockedThreads;
    public double runnableThreads;
    public double waitingThreads;
    public double timedWaitingThreads;

    public double heapUsedBytes;
    public double heapMaxBytes;

    public double gcPauseCount;
    public double gcPauseSumSeconds;
}
