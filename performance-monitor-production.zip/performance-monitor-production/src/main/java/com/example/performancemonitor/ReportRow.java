package com.example.performancemonitor;

import java.time.Instant;

public record ReportRow(
        Instant timestamp,
        String service,
        String scrapeStatus,
        String scrapeError,
        double requestDelta,
        double requestsPerMinute,
        double avgResponseMs,
        double activeRequests,
        double jdbcActive,
        double jdbcMax,
        double jdbcPending,
        double jdbcUsagePct,
        double processCpuPct,
        double systemCpuPct,
        double liveThreads,
        double runnableThreads,
        double blockedThreads,
        double waitingThreads,
        double timedWaitingThreads,
        double heapUsedPct,
        double gcPauseDelta,
        double avgGcPauseMs,
        String status
) {}
