package com.example.performancemonitor;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import java.io.BufferedWriter;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

@Component
public class ReportWriter {
    private final MonitorProperties properties;
    private final List<ReportRow> rows = new ArrayList<>();
    private final String[] headers = new String[]{
            "timestamp", "service", "scrapeStatus", "scrapeError", "requestDelta", "requestsPerMinute",
            "avgResponseMs", "activeRequests", "jdbcActive", "jdbcMax", "jdbcPending", "jdbcUsagePct",
            "processCpuPct", "systemCpuPct", "liveThreads", "runnableThreads", "blockedThreads",
            "waitingThreads", "timedWaitingThreads", "heapUsedPct", "gcPauseDelta", "avgGcPauseMs", "status"
    };

    public ReportWriter(MonitorProperties properties) {
        this.properties = properties;
    }

    public synchronized void write(ReportRow row) {
        try {
            Files.createDirectories(Path.of(properties.outputDir()));
            writeCsv(row);
            rows.add(row);
            writeExcel();
            writeHtml();
            System.out.printf("%s service=%s rpm=%.2f avgMs=%.2f jdbc=%.2f%% cpu=%.2f%% heap=%.2f%% status=%s%n",
                    row.timestamp(), row.service(), row.requestsPerMinute(), row.avgResponseMs(),
                    row.jdbcUsagePct(), row.processCpuPct(), row.heapUsedPct(), row.status());
        } catch (Exception e) {
            System.err.println("Failed to write report: " + e.getMessage());
        }
    }

    private void writeCsv(ReportRow row) throws Exception {
        Path csv = Path.of(properties.outputDir(), properties.csvFile());
        boolean exists = Files.exists(csv);

        try (BufferedWriter writer = Files.newBufferedWriter(csv, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
             CSVPrinter printer = exists
                     ? new CSVPrinter(writer, CSVFormat.DEFAULT)
                     : new CSVPrinter(writer, CSVFormat.DEFAULT.builder().setHeader(headers).build())) {
            printer.printRecord(toValues(row));
        }
    }

    private void writeExcel() throws Exception {
        Path xlsx = Path.of(properties.outputDir(), properties.excelFile());
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("performance");
            Row header = sheet.createRow(0);
            for (int i = 0; i < headers.length; i++) header.createCell(i).setCellValue(headers[i]);

            int r = 1;
            for (ReportRow row : rows) {
                Row excelRow = sheet.createRow(r++);
                Object[] values = toValues(row);
                for (int i = 0; i < values.length; i++) {
                    if (values[i] instanceof Number n) excelRow.createCell(i).setCellValue(n.doubleValue());
                    else excelRow.createCell(i).setCellValue(String.valueOf(values[i]));
                }
            }

            for (int i = 0; i < headers.length; i++) sheet.autoSizeColumn(i);

            try (OutputStream out = Files.newOutputStream(xlsx, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
                workbook.write(out);
            }
        }
    }

    private void writeHtml() throws Exception {
        Path html = Path.of(properties.outputDir(), properties.htmlFile());
        StringBuilder sb = new StringBuilder();
        sb.append("<html><head><title>Application Performance Report</title>");
        sb.append("<style>body{font-family:Arial}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccc;padding:5px;font-size:12px}th{background:#eee}</style>");
        sb.append("</head><body><h2>Application Performance Report</h2><table><tr>");
        for (String h : headers) sb.append("<th>").append(h).append("</th>");
        sb.append("</tr>");
        for (ReportRow row : rows) {
            sb.append("<tr>");
            for (Object value : toValues(row)) sb.append("<td>").append(escape(String.valueOf(value))).append("</td>");
            sb.append("</tr>");
        }
        sb.append("</table></body></html>");
        Files.writeString(html, sb.toString(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
    }

    private Object[] toValues(ReportRow r) {
        return new Object[]{
                r.timestamp(), r.service(), r.scrapeStatus(), r.scrapeError(), r.requestDelta(),
                r.requestsPerMinute(), r.avgResponseMs(), r.activeRequests(), r.jdbcActive(), r.jdbcMax(),
                r.jdbcPending(), r.jdbcUsagePct(), r.processCpuPct(), r.systemCpuPct(), r.liveThreads(),
                r.runnableThreads(), r.blockedThreads(), r.waitingThreads(), r.timedWaitingThreads(),
                r.heapUsedPct(), r.gcPauseDelta(), r.avgGcPauseMs(), r.status()
        };
    }

    private String escape(String value) {
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
