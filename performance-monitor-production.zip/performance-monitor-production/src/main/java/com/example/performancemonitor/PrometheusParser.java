package com.example.performancemonitor;

import org.springframework.stereotype.Component;
import java.time.Instant;

@Component
public class PrometheusParser {

    public MetricSnapshot parse(String serviceName, String body) {
        MetricSnapshot s = new MetricSnapshot();
        s.timestamp = Instant.now();
        s.service = serviceName;

        for (String line : body.split("\\R")) {
            if (line.isBlank() || line.startsWith("#")) continue;

            double value;
            try {
                value = extractValue(line);
            } catch (Exception ignored) {
                continue;
            }

            if (line.startsWith("http_server_requests_seconds_count")) s.requestCount += value;
            else if (line.startsWith("http_server_requests_seconds_sum")) s.requestSumSeconds += value;
            else if (line.startsWith("http_server_requests_active_seconds_count")) s.activeRequests += value;
            else if (line.startsWith("jdbc_connections_active") || line.startsWith("hikaricp_connections_active")) s.jdbcActive += value;
            else if (line.startsWith("jdbc_connections_idle") || line.startsWith("hikaricp_connections_idle")) s.jdbcIdle += value;
            else if (line.startsWith("jdbc_connections_max") || line.startsWith("hikaricp_connections_max")) s.jdbcMax += value;
            else if (line.startsWith("hikaricp_connections_pending")) s.jdbcPending += value;
            else if (line.startsWith("process_cpu_usage")) s.processCpu = value;
            else if (line.startsWith("system_cpu_usage")) s.systemCpu = value;
            else if (line.startsWith("jvm_threads_live_threads")) s.liveThreads = value;
            else if (line.startsWith("jvm_threads_daemon_threads")) s.daemonThreads = value;
            else if (line.startsWith("jvm_threads_states_threads") && line.contains("state=\"blocked\"")) s.blockedThreads = value;
            else if (line.startsWith("jvm_threads_states_threads") && line.contains("state=\"runnable\"")) s.runnableThreads = value;
            else if (line.startsWith("jvm_threads_states_threads") && line.contains("state=\"waiting\"")) s.waitingThreads = value;
            else if (line.startsWith("jvm_threads_states_threads") && line.contains("state=\"timed-waiting\"")) s.timedWaitingThreads = value;
            else if (line.startsWith("jvm_memory_used_bytes") && line.contains("area=\"heap\"")) s.heapUsedBytes += value;
            else if (line.startsWith("jvm_memory_max_bytes") && line.contains("area=\"heap\"")) s.heapMaxBytes += value;
            else if (line.startsWith("jvm_gc_pause_seconds_count")) s.gcPauseCount += value;
            else if (line.startsWith("jvm_gc_pause_seconds_sum")) s.gcPauseSumSeconds += value;
        }
        return s;
    }

    private double extractValue(String line) {
        String[] parts = line.trim().split("\\s+");
        return Double.parseDouble(parts[parts.length - 1]);
    }
}
