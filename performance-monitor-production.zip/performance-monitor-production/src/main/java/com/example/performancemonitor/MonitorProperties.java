package com.example.performancemonitor;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Positive;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import java.util.List;

@Validated
@ConfigurationProperties(prefix = "monitor")
public record MonitorProperties(
        @Positive long intervalMs,
        @Positive long connectTimeoutMs,
        @Positive long responseTimeoutMs,
        @NotBlank String outputDir,
        @NotBlank String csvFile,
        @NotBlank String excelFile,
        @NotBlank String htmlFile,
        String username,
        String password,
        @NotEmpty List<@Valid ServiceConfig> services,
        @Valid Thresholds thresholds
) {
    public record ServiceConfig(@NotBlank String name, @NotBlank String url) {}

    public record Thresholds(
            double slowResponseMs,
            double verySlowResponseMs,
            double jdbcUsageWarningPct,
            double jdbcUsageCriticalPct,
            double heapWarningPct,
            double heapCriticalPct,
            double cpuWarningPct,
            double cpuCriticalPct,
            double blockedThreadsWarning,
            double activeRequestsWarning
    ) {}
}
