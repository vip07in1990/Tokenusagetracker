package com.example.performancemonitor;

import io.netty.channel.ChannelOption;
import org.springframework.http.HttpHeaders;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class MetricsScraper {
    private final MonitorProperties properties;
    private final PrometheusParser parser;
    private final ReportRowFactory rowFactory;
    private final ReportWriter reportWriter;
    private final WebClient webClient;
    private final Map<String, MetricSnapshot> previousSnapshots = new ConcurrentHashMap<>();

    public MetricsScraper(MonitorProperties properties, PrometheusParser parser,
                          ReportRowFactory rowFactory, ReportWriter reportWriter) {
        this.properties = properties;
        this.parser = parser;
        this.rowFactory = rowFactory;
        this.reportWriter = reportWriter;

        HttpClient httpClient = HttpClient.create()
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, (int) properties.connectTimeoutMs())
                .responseTimeout(Duration.ofMillis(properties.responseTimeoutMs()));

        WebClient.Builder builder = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(httpClient));

        if (properties.username() != null && !properties.username().isBlank()) {
            builder.defaultHeaders(headers ->
                    headers.setBasicAuth(properties.username(), properties.password() == null ? "" : properties.password()));
        }

        this.webClient = builder.build();
    }

    @Scheduled(fixedDelayString = "${monitor.interval-ms}")
    public void scrapeAll() {
        for (MonitorProperties.ServiceConfig service : properties.services()) {
            scrapeOne(service);
        }
    }

    private void scrapeOne(MonitorProperties.ServiceConfig service) {
        MetricSnapshot current;
        try {
            String body = webClient.get()
                    .uri(service.url())
                    .header(HttpHeaders.ACCEPT, "text/plain")
                    .retrieve()
                    .bodyToMono(String.class)
                    .block(Duration.ofMillis(properties.responseTimeoutMs() + 5000));

            current = parser.parse(service.name(), body == null ? "" : body);
        } catch (Exception e) {
            current = new MetricSnapshot();
            current.timestamp = Instant.now();
            current.service = service.name();
            current.scrapeStatus = "FAILED";
            current.scrapeError = e.getClass().getSimpleName() + ": " + e.getMessage();
        }

        MetricSnapshot previous = previousSnapshots.get(service.name());
        ReportRow row = rowFactory.create(current, previous);
        reportWriter.write(row);

        if ("OK".equals(current.scrapeStatus)) {
            previousSnapshots.put(service.name(), current);
        }
    }
}
