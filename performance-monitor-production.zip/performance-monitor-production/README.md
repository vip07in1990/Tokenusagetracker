# Performance Monitor Utility

Scrapes Spring Boot `/actuator/prometheus` metrics at a regular interval and generates:

- CSV report
- Excel report
- HTML dashboard
- Health/bottleneck classification

## Build

```bash
mvn clean package
```

## Run

```bash
java -jar target/performance-monitor-1.0.0.jar
```

## Key report columns

- `requestsPerMinute`: throughput during the interval
- `avgResponseMs`: average response time during the interval
- `activeRequests`: currently running requests
- `jdbcUsagePct`: DB connection pool utilization
- `processCpuPct`: JVM process CPU usage
- `heapUsedPct`: heap pressure
- `blockedThreads`: Java lock contention
- `status`: calculated bottleneck/status

## Interpretation

- Low RPM + low active requests + low CPU = service is likely waiting for requests.
- High active requests + high response time = requests are piling up inside service.
- High JDBC usage/pending = DB connection pool bottleneck.
- High CPU = CPU saturation.
- High blocked threads = lock contention.
- High heap/GC = memory pressure.
