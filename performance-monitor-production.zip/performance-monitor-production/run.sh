#!/usr/bin/env bash
set -e
mvn clean package
java -jar target/performance-monitor-1.0.0.jar
