"""
SQL Server Performance AI Analyzer

Purpose:
- Collect SQL Server DMV/Query Store style data
- Detect performance issues
- Generate readable HTML and Markdown reports

Run demo mode:
  python sql_performance_analyzer.py --demo

Generate report:
  python sql_performance_analyzer.py --demo --html report.html --markdown report.md

Production integration idea:
- Replace load_demo_data() with pyodbc queries against your SQL Server DMVs.
- Optionally send the JSON summary to OpenAI/Azure OpenAI for narrative RCA.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd


@dataclass
class Issue:
    severity: str
    area: str
    title: str
    evidence: str
    recommendation: str


def load_demo_data() -> dict[str, pd.DataFrame]:
    query_stats = pd.DataFrame([
        {
            "query_name": "GetCanonicalTrades",
            "query_text": "EXEC GetCanonicalTrades @StartDate, @EndDate",
            "avg_duration_ms": 540000,
            "max_duration_ms": 780000,
            "avg_cpu_ms": 300000,
            "avg_logical_reads": 12000000,
            "avg_physical_reads": 300000,
            "execution_count": 10,
            "plan_count": 3,
        },
        {
            "query_name": "PositionSecurityJoin",
            "query_text": "SELECT * FROM Positions JOIN Securities ON Positions.SecurityID = Securities.ID",
            "avg_duration_ms": 2000,
            "max_duration_ms": 2500,
            "avg_cpu_ms": 1500,
            "avg_logical_reads": 8000000,
            "avg_physical_reads": 200000,
            "execution_count": 20,
            "plan_count": 1,
        },
        {
            "query_name": "OpenOrdersByStatus",
            "query_text": "SELECT SUM(Quantity) FROM Orders WHERE Status = 'Open'",
            "avg_duration_ms": 50,
            "max_duration_ms": 60,
            "avg_cpu_ms": 25,
            "avg_logical_reads": 10000,
            "avg_physical_reads": 500,
            "execution_count": 5000,
            "plan_count": 1,
        },
    ])

    wait_stats = pd.DataFrame([
        {"wait_type": "PAGEIOLATCH_SH", "wait_time_ms": 1200000, "waiting_tasks_count": 10000},
        {"wait_type": "CXPACKET", "wait_time_ms": 800000, "waiting_tasks_count": 8000},
        {"wait_type": "LCK_M_S", "wait_time_ms": 400000, "waiting_tasks_count": 5000},
        {"wait_type": "WRITELOG", "wait_time_ms": 200000, "waiting_tasks_count": 2000},
    ])

    missing_indexes = pd.DataFrame([
        {
            "table_name": "dbo.Trades",
            "equality_columns": "TradeDate",
            "included_columns": "Quantity, Price, ProductId",
            "avg_user_impact": 90,
            "unique_compiles": 25,
        },
        {
            "table_name": "dbo.Positions",
            "equality_columns": "SecurityID",
            "included_columns": "PositionDate, Quantity",
            "avg_user_impact": 75,
            "unique_compiles": 15,
        },
    ])

    blocking = pd.DataFrame([
        {"blocked_session_id": 58, "blocking_session_id": 12, "wait_type": "LCK_M_S", "wait_time_ms": 200000},
        {"blocked_session_id": 59, "blocking_session_id": 12, "wait_type": "LCK_M_S", "wait_time_ms": 180000},
    ])

    return {
        "query_stats": query_stats,
        "wait_stats": wait_stats,
        "missing_indexes": missing_indexes,
        "blocking": blocking,
    }


def detect_issues(data: dict[str, pd.DataFrame]) -> list[Issue]:
    issues: list[Issue] = []
    queries = data["query_stats"].copy()

    for _, q in queries.iterrows():
        if q.avg_duration_ms >= 1000:
            issues.append(Issue(
                "HIGH" if q.avg_duration_ms >= 60000 else "MEDIUM",
                "Slow Query",
                f"{q.query_name} has high duration",
                f"Average duration {q.avg_duration_ms:,.0f} ms, max {q.max_duration_ms:,.0f} ms, executions {q.execution_count}",
                "Check Query Store plan history, execution plan operators, parameter sniffing, stale stats, and index usage.",
            ))
        if q.avg_logical_reads >= 5_000_000:
            issues.append(Issue(
                "HIGH",
                "Logical Reads",
                f"{q.query_name} has high logical reads",
                f"Average logical reads {q.avg_logical_reads:,.0f}",
                "Look for scans, missing indexes, non-sargable predicates, SELECT *, and large joins.",
            ))
        if q.plan_count >= 3:
            issues.append(Issue(
                "MEDIUM",
                "Plan Stability",
                f"{q.query_name} has multiple plans",
                f"Observed {q.plan_count} plans",
                "Compare Query Store plans. This can indicate parameter-sensitive plan behavior or statistics changes.",
            ))

    waits = data["wait_stats"].copy()
    total_wait = waits.wait_time_ms.sum()
    waits["wait_pct"] = waits.wait_time_ms / total_wait * 100 if total_wait else 0
    for _, w in waits.iterrows():
        if w.wait_pct >= 20:
            if str(w.wait_type).startswith("PAGEIO"):
                recommendation = "Check storage latency, buffer pool pressure, missing indexes, and excessive physical reads."
            elif str(w.wait_type).startswith("CX"):
                recommendation = "Review expensive parallel plans, MAXDOP, cost threshold for parallelism, and skewed operators."
            elif str(w.wait_type).startswith("LCK"):
                recommendation = "Find blocker session, long transactions, missing indexes causing long locks, and transaction isolation level."
            else:
                recommendation = "Investigate this dominant wait using SQL Server wait statistics and workload timeline."
            issues.append(Issue(
                "HIGH" if w.wait_pct >= 35 else "MEDIUM",
                "Wait Stats",
                f"Dominant wait type: {w.wait_type}",
                f"{w.wait_pct:.1f}% of total waits, wait time {w.wait_time_ms:,.0f} ms",
                recommendation,
            ))

    indexes = data["missing_indexes"]
    for _, idx in indexes.iterrows():
        if idx.avg_user_impact >= 70:
            issues.append(Issue(
                "MEDIUM",
                "Missing Index",
                f"High impact missing index on {idx.table_name}",
                f"Equality columns: {idx.equality_columns}; estimated impact {idx.avg_user_impact:.0f}%",
                "Validate with execution plan and workload before creating index. Avoid duplicate/wide indexes.",
            ))

    blocking = data["blocking"]
    if not blocking.empty:
        issues.append(Issue(
            "HIGH",
            "Blocking",
            "Blocking sessions detected",
            f"{len(blocking)} blocked session(s), max wait {blocking.wait_time_ms.max():,.0f} ms",
            "Identify root blocker, transaction duration, isolation level, missing indexes, and application transaction boundaries.",
        ))

    return issues


def dataframe_html(df: pd.DataFrame) -> str:
    return df.to_html(index=False, border=0, classes="data-table", escape=False)


def generate_html(data: dict[str, pd.DataFrame], issues: list[Issue], output: Path) -> None:
    severity_rank = {"HIGH": 1, "MEDIUM": 2, "LOW": 3}
    issues_sorted = sorted(issues, key=lambda x: severity_rank.get(x.severity, 9))
    issue_cards = "\n".join(
        f"""
        <div class="card {i.severity.lower()}">
          <div class="badge">{i.severity}</div>
          <h3>{i.title}</h3>
          <p><b>Area:</b> {i.area}</p>
          <p><b>Evidence:</b> {i.evidence}</p>
          <p><b>Recommended next step:</b> {i.recommendation}</p>
        </div>
        """ for i in issues_sorted
    )

    waits = data["wait_stats"].copy()
    total_wait = waits.wait_time_ms.sum()
    waits["wait_pct"] = (waits.wait_time_ms / total_wait * 100).round(2) if total_wait else 0

    html = f"""
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>SQL Server Performance Analyzer Report</title>
  <style>
    body {{ font-family: Arial, sans-serif; margin: 24px; background: #f6f8fb; color: #1f2937; }}
    h1, h2 {{ color: #111827; }}
    .summary {{ display: flex; gap: 16px; flex-wrap: wrap; margin: 16px 0; }}
    .metric {{ background: white; border-radius: 12px; padding: 16px; min-width: 180px; box-shadow: 0 1px 4px #ddd; }}
    .metric .value {{ font-size: 28px; font-weight: bold; }}
    .card {{ background: white; border-radius: 12px; padding: 16px; margin: 12px 0; box-shadow: 0 1px 4px #ddd; border-left: 8px solid #9ca3af; }}
    .high {{ border-left-color: #dc2626; }}
    .medium {{ border-left-color: #f59e0b; }}
    .low {{ border-left-color: #10b981; }}
    .badge {{ display: inline-block; padding: 4px 10px; border-radius: 20px; background: #e5e7eb; font-weight: bold; }}
    table.data-table {{ width: 100%; border-collapse: collapse; background: white; margin: 12px 0 24px 0; box-shadow: 0 1px 4px #ddd; }}
    table.data-table th {{ text-align: left; background: #111827; color: white; padding: 10px; }}
    table.data-table td {{ padding: 10px; border-bottom: 1px solid #e5e7eb; vertical-align: top; }}
    .footer {{ color: #6b7280; font-size: 13px; margin-top: 32px; }}
  </style>
</head>
<body>
  <h1>SQL Server Performance Analyzer Report</h1>
  <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>

  <div class="summary">
    <div class="metric"><div>Total Issues</div><div class="value">{len(issues)}</div></div>
    <div class="metric"><div>High Issues</div><div class="value">{sum(1 for i in issues if i.severity == 'HIGH')}</div></div>
    <div class="metric"><div>Queries Checked</div><div class="value">{len(data['query_stats'])}</div></div>
    <div class="metric"><div>Blocked Sessions</div><div class="value">{len(data['blocking'])}</div></div>
  </div>

  <h2>Issue Highlights</h2>
  {issue_cards}

  <h2>Top Query Statistics</h2>
  {dataframe_html(data['query_stats'].sort_values('avg_duration_ms', ascending=False))}

  <h2>Wait Statistics</h2>
  {dataframe_html(waits.sort_values('wait_time_ms', ascending=False))}

  <h2>Missing Index Recommendations</h2>
  {dataframe_html(data['missing_indexes'])}

  <h2>Blocking Sessions</h2>
  {dataframe_html(data['blocking'])}

  <h2>How to Use This Report</h2>
  <p>Start with HIGH severity items. For slow stored procedures, compare Query Store plans before and after the slowdown. For high logical reads, inspect execution plans for scans and missing indexes. For blocking, identify the root blocker before tuning individual blocked queries.</p>

  <div class="footer">This report is advisory. Validate index and query changes in lower environments before production deployment.</div>
</body>
</html>
"""
    output.write_text(html, encoding="utf-8")


def generate_markdown(data: dict[str, pd.DataFrame], issues: list[Issue], output: Path) -> None:
    lines: list[str] = []
    lines.append("# SQL Server Performance Analyzer Report")
    lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    lines.append("## Issue Highlights")
    for issue in issues:
        lines.append(f"### [{issue.severity}] {issue.title}")
        lines.append(f"- Area: {issue.area}")
        lines.append(f"- Evidence: {issue.evidence}")
        lines.append(f"- Recommendation: {issue.recommendation}\n")
    for title, df in data.items():
        lines.append(f"## {title.replace('_', ' ').title()}")
        lines.append(df.to_markdown(index=False))
        lines.append("")
    output.write_text("\n".join(lines), encoding="utf-8")


def export_json(data: dict[str, pd.DataFrame], issues: list[Issue], output: Path) -> None:
    payload: dict[str, Any] = {
        "generated_at": datetime.now().isoformat(),
        "issues": [asdict(i) for i in issues],
        "tables": {name: df.to_dict(orient="records") for name, df in data.items()},
    }
    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--demo", action="store_true", help="Run using demo data")
    parser.add_argument("--html", default="sql_performance_report.html")
    parser.add_argument("--markdown", default="sql_performance_report.md")
    parser.add_argument("--json", default="sql_performance_report.json")
    args = parser.parse_args()

    data = load_demo_data()
    issues = detect_issues(data)
    generate_html(data, issues, Path(args.html))
    generate_markdown(data, issues, Path(args.markdown))
    export_json(data, issues, Path(args.json))
    print(f"Generated: {args.html}, {args.markdown}, {args.json}")


if __name__ == "__main__":
    main()
