# SQL Server Performance Analyzer Report
Generated: 2026-06-24 13:12:59

## Issue Highlights
### [HIGH] GetCanonicalTrades has high duration
- Area: Slow Query
- Evidence: Average duration 540,000 ms, max 780,000 ms, executions 10
- Recommendation: Check Query Store plan history, execution plan operators, parameter sniffing, stale stats, and index usage.

### [HIGH] GetCanonicalTrades has high logical reads
- Area: Logical Reads
- Evidence: Average logical reads 12,000,000
- Recommendation: Look for scans, missing indexes, non-sargable predicates, SELECT *, and large joins.

### [MEDIUM] GetCanonicalTrades has multiple plans
- Area: Plan Stability
- Evidence: Observed 3 plans
- Recommendation: Compare Query Store plans. This can indicate parameter-sensitive plan behavior or statistics changes.

### [MEDIUM] PositionSecurityJoin has high duration
- Area: Slow Query
- Evidence: Average duration 2,000 ms, max 2,500 ms, executions 20
- Recommendation: Check Query Store plan history, execution plan operators, parameter sniffing, stale stats, and index usage.

### [HIGH] PositionSecurityJoin has high logical reads
- Area: Logical Reads
- Evidence: Average logical reads 8,000,000
- Recommendation: Look for scans, missing indexes, non-sargable predicates, SELECT *, and large joins.

### [HIGH] Dominant wait type: PAGEIOLATCH_SH
- Area: Wait Stats
- Evidence: 46.2% of total waits, wait time 1,200,000 ms
- Recommendation: Check storage latency, buffer pool pressure, missing indexes, and excessive physical reads.

### [MEDIUM] Dominant wait type: CXPACKET
- Area: Wait Stats
- Evidence: 30.8% of total waits, wait time 800,000 ms
- Recommendation: Review expensive parallel plans, MAXDOP, cost threshold for parallelism, and skewed operators.

### [MEDIUM] High impact missing index on dbo.Trades
- Area: Missing Index
- Evidence: Equality columns: TradeDate; estimated impact 90%
- Recommendation: Validate with execution plan and workload before creating index. Avoid duplicate/wide indexes.

### [MEDIUM] High impact missing index on dbo.Positions
- Area: Missing Index
- Evidence: Equality columns: SecurityID; estimated impact 75%
- Recommendation: Validate with execution plan and workload before creating index. Avoid duplicate/wide indexes.

### [HIGH] Blocking sessions detected
- Area: Blocking
- Evidence: 2 blocked session(s), max wait 200,000 ms
- Recommendation: Identify root blocker, transaction duration, isolation level, missing indexes, and application transaction boundaries.

## Query Stats
| query_name           | query_text                                                                      |   avg_duration_ms |   max_duration_ms |   avg_cpu_ms |   avg_logical_reads |   avg_physical_reads |   execution_count |   plan_count |
|:---------------------|:--------------------------------------------------------------------------------|------------------:|------------------:|-------------:|--------------------:|---------------------:|------------------:|-------------:|
| GetCanonicalTrades   | EXEC GetCanonicalTrades @StartDate, @EndDate                                    |            540000 |            780000 |       300000 |            12000000 |               300000 |                10 |            3 |
| PositionSecurityJoin | SELECT * FROM Positions JOIN Securities ON Positions.SecurityID = Securities.ID |              2000 |              2500 |         1500 |             8000000 |               200000 |                20 |            1 |
| OpenOrdersByStatus   | SELECT SUM(Quantity) FROM Orders WHERE Status = 'Open'                          |                50 |                60 |           25 |               10000 |                  500 |              5000 |            1 |

## Wait Stats
| wait_type      |   wait_time_ms |   waiting_tasks_count |
|:---------------|---------------:|----------------------:|
| PAGEIOLATCH_SH |        1200000 |                 10000 |
| CXPACKET       |         800000 |                  8000 |
| LCK_M_S        |         400000 |                  5000 |
| WRITELOG       |         200000 |                  2000 |

## Missing Indexes
| table_name    | equality_columns   | included_columns           |   avg_user_impact |   unique_compiles |
|:--------------|:-------------------|:---------------------------|------------------:|------------------:|
| dbo.Trades    | TradeDate          | Quantity, Price, ProductId |                90 |                25 |
| dbo.Positions | SecurityID         | PositionDate, Quantity     |                75 |                15 |

## Blocking
|   blocked_session_id |   blocking_session_id | wait_type   |   wait_time_ms |
|---------------------:|----------------------:|:------------|---------------:|
|                   58 |                    12 | LCK_M_S     |         200000 |
|                   59 |                    12 | LCK_M_S     |         180000 |
