"""
Streamlit UI for SQL Server Performance AI Analyzer

Run:
  pip install -r requirements.txt
  streamlit run streamlit_app.py

This demo uses sample data. Replace load_demo_data() with SQL Server DMV/Query Store
collection using pyodbc for production.
"""

import pandas as pd
import streamlit as st
from sql_performance_analyzer import load_demo_data, detect_issues

st.set_page_config(page_title="SQL Performance AI Analyzer", layout="wide")

st.title("SQL Server Performance AI Analyzer")
st.caption("Interactive report for slow queries, waits, blocking and missing index recommendations")

data = load_demo_data()
issues = detect_issues(data)

high = sum(1 for i in issues if i.severity == "HIGH")
medium = sum(1 for i in issues if i.severity == "MEDIUM")

c1, c2, c3, c4 = st.columns(4)
c1.metric("Total Issues", len(issues))
c2.metric("High Severity", high)
c3.metric("Medium Severity", medium)
c4.metric("Blocked Sessions", len(data["blocking"]))

st.header("Issue Highlights")
severity_filter = st.multiselect("Severity", ["HIGH", "MEDIUM", "LOW"], default=["HIGH", "MEDIUM"])
for issue in issues:
    if issue.severity not in severity_filter:
        continue
    with st.expander(f"{issue.severity} | {issue.area} | {issue.title}", expanded=issue.severity == "HIGH"):
        st.write(f"**Evidence:** {issue.evidence}")
        st.write(f"**Recommendation:** {issue.recommendation}")

st.header("Query Statistics")
queries = data["query_stats"].sort_values("avg_duration_ms", ascending=False)
st.dataframe(queries, use_container_width=True)
st.bar_chart(queries.set_index("query_name")[["avg_duration_ms", "avg_cpu_ms"]])

st.header("Wait Statistics")
waits = data["wait_stats"].copy()
total_wait = waits["wait_time_ms"].sum()
waits["wait_pct"] = waits["wait_time_ms"] / total_wait * 100 if total_wait else 0
st.dataframe(waits.sort_values("wait_time_ms", ascending=False), use_container_width=True)
st.bar_chart(waits.set_index("wait_type")[["wait_time_ms"]])

st.header("Missing Index Recommendations")
st.dataframe(data["missing_indexes"], use_container_width=True)

st.header("Blocking Sessions")
st.dataframe(data["blocking"], use_container_width=True)

st.header("Next Steps")
st.markdown(
    """
1. Start with HIGH severity findings.
2. For slow procedures, compare Query Store plans before and after the slowdown.
3. For high logical reads, inspect actual execution plans and missing indexes.
4. For blocking, identify the root blocker and long-running transaction.
5. Validate all index/query changes outside production first.
"""
)
