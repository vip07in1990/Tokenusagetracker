# SQL Server Performance AI Analyzer

This package contains:

- `sql_performance_analyzer.py` - CLI report generator
- `streamlit_app.py` - interactive Streamlit UI
- `requirements.txt` - dependencies

## Run CLI demo

```bash
pip install -r requirements.txt
python sql_performance_analyzer.py --demo --html sql_performance_report.html --markdown sql_performance_report.md
```

## Run Streamlit UI

```bash
pip install -r requirements.txt
streamlit run streamlit_app.py
```

## Production changes

Replace `load_demo_data()` with SQL Server DMV and Query Store queries using `pyodbc`.
Recommended collectors:

- `sys.dm_exec_query_stats`
- `sys.dm_exec_procedure_stats`
- `sys.dm_os_wait_stats`
- `sys.dm_exec_requests`
- `sys.dm_tran_locks`
- Query Store views
- Missing index DMVs

## Python or Spring Boot?

Use Python for analytics, quick reporting, Streamlit dashboards and AI/RCA generation.
Use Spring Boot for enterprise deployment, authentication, scheduled jobs, APIs, Jenkins/OpenShift integration and integration with existing Java services.
A practical design is: Spring Boot collector/orchestrator + Python/AI analyzer module.
